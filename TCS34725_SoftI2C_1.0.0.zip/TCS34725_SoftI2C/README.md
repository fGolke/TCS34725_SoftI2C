For license see TCS34725_SoftI2C.h

Library to use the TCS on a software emulated I2C Bus.


Version 1.0.0	2020-11-15
First assembly of the library